## How to Use
1. Unzip the program to desired location.
2. Open the program.
3. Generate a random palette or chose your starting color.
4. Save the palette as a 320x60 png grid, saved in the same directory as the .exe.
5. Use the palette for your art projects.